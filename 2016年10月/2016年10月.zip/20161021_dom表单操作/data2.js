var data = {
	list:{
		pid:0,
		li1:{
			name:"所有分类",
			list:{
				pid:1,
				li1:{
					name: "数码家电",
					list:{
						pid:2,
						li1:{
							name: "居家日用"
						},
						li2:{
							name: "居家日用"
						},
						li3:{
							name: "居家日用"
						},
						li4:{
							name: "居家日用"
						}
					}
				},
				li2:{
					name: "户外运动",
					list:{
						pid:2,
						li1:{
							name: "厨房用品"
						},
						li2:{
							name: "厨房用品"
						},
						li3:{
							name: "厨房用品"
						},
						li4:{
							name: "厨房用品"
						}
					}
				},
				li3:{
					name: "妙味课堂",
					list:{
						pid:2,
						li1:{
							name: "学习乐园"
						},
						li2:{
							name: "学习乐园"
						},
						li3:{
							name: "学习乐园"
						},
						li4:{
							name: "学习乐园"
						}
					}
				}
			}
		},
		li2:{
			name:"家具家电",
			list:{
				pid:1,
				li1:{
					name: "数码家电",
					list:{
						pid:2,
						li1:{
							name: "居家日用"
						},
						li2:{
							name: "居家日用"
						},
						li3:{
							name: "居家日用"
						},
						li4:{
							name: "居家日用"
						}
					}
				},
				li2:{
					name: "户外运动",
					list:{
						pid:2,
						li1:{
							name: "厨房用品"
						},
						li2:{
							name: "厨房用品"
						},
						li3:{
							name: "厨房用品"
						},
						li4:{
							name: "厨房用品"
						}
					}
				},
				li3:{
					name: "妙味课堂",
					list:{
						pid:2,
						li1:{
							name: "学习乐园"
						},
						li2:{
							name: "学习乐园"
						},
						li3:{
							name: "学习乐园"
						},
						li4:{
							name: "学习乐园"
						}
					}
				}
			}
		},
		li3:{
			name:"妙味视频",
			list:{
				pid:1,
				li1:{
					name: "数码家电",
					list:{
						pid:2,
						li1:{
							name: "居家日用"
						},
						li2:{
							name: "居家日用"
						},
						li3:{
							name: "居家日用"
						},
						li4:{
							name: "居家日用"
						}
					}
				},
				li2:{
					name: "户外运动",
					list:{
						pid:2,
						li1:{
							name: "厨房用品"
						},
						li2:{
							name: "厨房用品"
						},
						li3:{
							name: "厨房用品"
						},
						li4:{
							name: "厨房用品"
						}
					}
				},
				li3:{
					name: "妙味课堂",
					list:{
						pid:2,
						li1:{
							name: "学习乐园"
						},
						li2:{
							name: "学习乐园"
						},
						li3:{
							name: "学习乐园"
						},
						li4:{
							name: "学习乐园"
						}
					}
				}
			}
		}
	}	
};